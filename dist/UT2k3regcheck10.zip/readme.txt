UT2k3 registry check by H-e-a-d

thank you for downloading my small tool ...

this tool will update your registry after you have
done format c: or something like that

please visit 

http://fof-clan.com
#fof @ quakenet 

if you got any questions mail to head@fof-clan.com