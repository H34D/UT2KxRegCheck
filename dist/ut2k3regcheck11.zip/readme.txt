Name: UT2k3 registry check
Version: 1.1
Autor: FoF|Head
Size: 521.216 byte 
Operating systems: WIN 95(not tested)/98/ME/2K/XP
===================================================================================
Thank you for downloading my small registry check tool .. 
now you are able to view/change your CD-Key and your UT2k3-path in a simple 
and easy way.
If you want to change the UT2k3-path and your CD-key simply click 
on "allow changes", make your changes and press insert.

Changelog -> 1.0 (26. nov. 2002)
everything

Changelog 1.0 -> 1.1 (28. nov. 2002) 

added: the UT-path search button
added: the "allow changes" button for easy change of your cd-key
added: ability to view the CD-Key and UT2k3 path
added: stat "hidden" for checkboxes when regkey allready exsits
added: ability to resfresh registry keys if external actions changed them
fixed: spelling errors
fixed: adding regkey for maps/links/protocols/umods doesnt work right
fixed: the design .. looks better now imho
fixed: the border is not longer sizeable 
-----------------------------------------------------------------------------------

please send your questions and bugreports to head@fof-clan.com

visit http://fof-clan.com
#fof on Q-net